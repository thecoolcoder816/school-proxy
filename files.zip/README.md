# Rammerhead Proxy in Codespaces

This project runs [Rammerhead](https://github.com/binary-person/rammerhead), a web proxy server, inside a GitHub Codespace.

## How to use

1. **Open in Codespaces**  
   Click "Code" > "Create codespace on main".

2. **Wait for setup**  
   The project will auto-install dependencies.

3. **Start the proxy**  
   Run in the terminal: